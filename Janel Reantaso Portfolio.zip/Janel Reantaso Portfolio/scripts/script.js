
// var check1 = document.getElementById("check1").checked;
// var check2 = document.getElementById("check2").checked;
// var check3 = document.getElementById("check3").checked;


// script loader
$(window).on('load',function(){
    $(".body-loader")
    $(".loader").fadeOut(1000);
    $(".container").fadeIn(1000);
});

// Type animation
var typingEffect = new Typed(".multiText", {
    strings : ["Janel B. Mayo","Digital Entrepreneur"],
    loop : true,
    typeSpeed : 100,
    backSpeed : 80,
    backDelay : 1500
});


